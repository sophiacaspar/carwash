package state;

public class Car {

	public int id;

	public Car(int id) {
		this.id = id;
	}

}
